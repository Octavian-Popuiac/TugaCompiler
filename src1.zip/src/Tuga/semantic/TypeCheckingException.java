package Tuga.semantic;

public class TypeCheckingException extends RuntimeException{
    public TypeCheckingException(String message){
        super(message);
    }
}
